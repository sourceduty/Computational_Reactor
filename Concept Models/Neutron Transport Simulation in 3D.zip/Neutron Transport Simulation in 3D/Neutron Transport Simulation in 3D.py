import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# Parameters
Lx, Ly, Lz = 10.0, 10.0, 10.0  # Dimensions of the medium
Nx, Ny, Nz = 50, 50, 50  # Number of cells in each dimension
dx, dy, dz = Lx / Nx, Ly / Ny, Lz / Nz  # Cell size

# Energy grid and temperature feedback
energy_levels = np.array([0.025, 1.0, 10.0])  # MeV, thermal, fast, epithermal
initial_temperature = 300.0  # Initial temperature in Kelvin
temperature = np.full((Nx, Ny, Nz), initial_temperature)

# Cross sections (varying across the medium and energy levels)
sigma_absorption = np.random.uniform(0.05, 0.15, (Nx, Ny, Nz, len(energy_levels)))
sigma_scattering = np.random.uniform(0.01, 0.05, (Nx, Ny, Nz, len(energy_levels)))
sigma_fission = np.random.uniform(0.0, 0.02, (Nx, Ny, Nz, len(energy_levels)))

# Initial neutron distribution (concentrated at the center) across energy levels
neutrons = np.zeros((Nx, Ny, Nz, len(energy_levels)))
neutrons[Nx//2, Ny//2, Nz//2, 0] = 1e5  # Initial thermal neutron source at the center

# Delayed neutron parameters
delayed_fraction = 0.0065  # Typical delayed neutron fraction
delayed_lifetimes = np.array([0.1, 1.0, 10.0])  # Seconds, group lifetimes

# Time parameters
dt = 0.005  # Initial time step
total_time = 2.0  # Total simulation time
adaptive_dt = True  # Adaptive time step

def neutron_transport_3d(neutrons, sigma_absorption, sigma_scattering, sigma_fission, temperature, dt, dx, dy, dz):
    Nx, Ny, Nz, E = neutrons.shape
    new_neutrons = np.zeros((Nx, Ny, Nz, E))
    
    for i in range(Nx):
        for j in range(Ny):
            for k in range(Nz):
                for e in range(E):
                    # Transport to neighboring cells
                    if i > 0:
                        transport_left = neutrons[i, j, k, e] * dt / dx
                        new_neutrons[i - 1, j, k, e] += transport_left
                        neutrons[i, j, k, e] -= transport_left
                    
                    if i < Nx - 1:
                        transport_right = neutrons[i, j, k, e] * dt / dx
                        new_neutrons[i + 1, j, k, e] += transport_right
                        neutrons[i, j, k, e] -= transport_right
                    
                    if j > 0:
                        transport_down = neutrons[i, j, k, e] * dt / dy
                        new_neutrons[i, j - 1, k, e] += transport_down
                        neutrons[i, j, k, e] -= transport_down
                    
                    if j < Ny - 1:
                        transport_up = neutrons[i, j, k, e] * dt / dy
                        new_neutrons[i, j + 1, k, e] += transport_up
                        neutrons[i, j, k, e] -= transport_up
                    
                    if k > 0:
                        transport_back = neutrons[i, j, k, e] * dt / dz
                        new_neutrons[i, j, k - 1, e] += transport_back
                        neutrons[i, j, k, e] -= transport_back
                    
                    if k < Nz - 1:
                        transport_forward = neutrons[i, j, k, e] * dt / dz
                        new_neutrons[i, j, k + 1, e] += transport_forward
                        neutrons[i, j, k, e] -= transport_forward
                    
                    # Absorption, scattering, and fission
                    absorbed = neutrons[i, j, k, e] * sigma_absorption[i, j, k, e] * dt
                    scattered = neutrons[i, j, k, e] * sigma_scattering[i, j, k, e] * dt
                    fission = neutrons[i, j, k, e] * sigma_fission[i, j, k, e] * dt * 2.5  # 2.5 neutrons per fission
                    
                    # Consider temperature feedback on cross-sections
                    temperature_feedback = 1.0 + 0.01 * (temperature[i, j, k] - initial_temperature)
                    neutrons[i, j, k, e] -= absorbed * temperature_feedback + scattered * temperature_feedback
                    new_neutrons[i, j, k, e] += scattered * temperature_feedback + fission * temperature_feedback
    
    return new_neutrons

def apply_boundary_conditions(neutrons, boundary_type="reflective"):
    Nx, Ny, Nz, E = neutrons.shape
    
    if boundary_type == "absorbing":
        neutrons[0, :, :, :] = 0.0
        neutrons[Nx-1, :, :, :] = 0.0
        neutrons[:, 0, :, :] = 0.0
        neutrons[:, Ny-1, :, :] = 0.0
        neutrons[:, :, 0, :] = 0.0
        neutrons[:, :, Nz-1, :] = 0.0
    
    elif boundary_type == "reflective":
        neutrons[0, :, :, :] = neutrons[1, :, :, :]
        neutrons[Nx-1, :, :, :] = neutrons[Nx-2, :, :, :]
        neutrons[:, 0, :, :] = neutrons[:, 1, :, :]
        neutrons[:, Ny-1, :, :] = neutrons[:, Ny-2, :, :]
        neutrons[:, :, 0, :] = neutrons[:, :, 1, :]
        neutrons[:, :, Nz-1, :] = neutrons[:, :, Nz-2, :]
    
    return neutrons

# Run the simulation
time_steps = int(total_time / dt)
neutron_history = []

for step in range(time_steps):
    neutrons = neutron_transport_3d(neutrons, sigma_absorption, sigma_scattering, sigma_fission, temperature, dt, dx, dy, dz)
    neutrons = apply_boundary_conditions(neutrons, boundary_type="reflective")
    
    if adaptive_dt:
        dt = 0.5 / np.max(neutrons)  # Adjust time step based on maximum neutron flux
    
    neutron_history.append(neutrons.copy())

neutron_history = np.array(neutron_history)

# Visualization of neutron distribution over time
fig, ax = plt.subplots(figsize=(10, 8))

def animate(frame):
    ax.clear()
    mid_slice = np.sum(neutron_history[frame][:, :, Nz//2, :], axis=-1)  # Sum over energy levels
    cax = ax.imshow(mid_slice, extent=[0, Lx, 0, Ly], origin='lower', aspect='auto', cmap='hot')
    ax.set_title(f"Time = {frame * dt:.2f} s")
    ax.set_xlabel('X Position')
    ax.set_ylabel('Y Position')
    return cax

ani = FuncAnimation(fig, animate, frames=time_steps, interval=50, blit=False)
plt.colorbar(animate(time_steps-1), ax=ax, label='Neutron Density')
plt.show()
